import { Component } from '@angular/core';
import { ModalController, NavController } from '@ionic/angular';

@Component({
  selector: 'app-start-game',
  templateUrl: './start-game.page.html',
  styleUrls: ['./start-game.page.scss'],
})
export class StartGamePage {
  
  valorRodada: number;  // Variável para armazenar o valor da rodada

  constructor(
    private modalCtrl: ModalController,
    private navCtrl: NavController
  ) {}

  // Função para iniciar o jogo após o popup
  async iniciarJogo() {
    this.navCtrl.navigateForward('/question');
  }

  // Função para cancelar e fechar o modal
  async cancelar() {
    this.navCtrl.navigateBack('/menu');
  }
}
