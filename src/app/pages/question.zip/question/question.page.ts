import { Component, OnInit, OnDestroy } from '@angular/core';
import { NavController, ModalController } from '@ionic/angular';
import { PrizeInfo } from 'src/app/models/prize-info';
import { Question, QuestionAnswer } from 'src/app/models/question';
import { QuestionService } from '../../services/question.service';
import { environment } from 'src/environments/environment';
import { EndingPage } from '../ending/ending.page';
import { AudioService } from '../../services/audio.service'; // Importa o serviço de áudio

@Component({
  selector: 'app-question',
  templateUrl: './question.page.html',
  styleUrls: ['./question.page.scss'],
})
export class QuestionPage implements OnInit, OnDestroy {
  curQuestion: Question | null = null;  // Pergunta atual
  prizeInfo: PrizeInfo | null = null;   // Informações sobre os prêmios
  timeLeft: number = 30;                // Tempo restante para responder
  private intervalID: any = null;       // ID do temporizador para controle
  isMusicPlaying: boolean = true;       // Controle para indicar se a música está tocando

  constructor(
    private navCtrl: NavController,
    private modalCtrl: ModalController,
    private questionService: QuestionService,
    private audioService: AudioService // Injeta o serviço de áudio
  ) {}

  ngOnInit(): void {
    this.restartGame();  // Reinicia o jogo ao carregar a página
  }

  ngOnDestroy(): void {
    this.clearTimer();  // Limpa o temporizador ao sair da página
    this.audioService.pauseMusic(); // Pausa a música ao sair da página
  }

  // Função para pausar/retomar a música
  toggleMusic(): void {
    if (this.isMusicPlaying) {
      this.audioService.pauseMusic(); // Pausa a música
    } else {
      this.audioService.playMusic(); // Retoma a música sem precisar de um arquivo
    }
    this.isMusicPlaying = !this.isMusicPlaying; // Alterna o estado de reprodução
  }

  // Função para falar o texto, pausando temporariamente a música
  speakText(text: string): void {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'pt-BR';

      // Pausar a música enquanto o texto é falado
      if (this.isMusicPlaying) {
        this.audioService.pauseMusic();
      }

      utterance.onend = () => {
        // Retomar a música após a fala
        if (this.isMusicPlaying) {
          this.audioService.playMusic();
        }
      };

      window.speechSynthesis.speak(utterance);
    } else {
      console.error('Speech Synthesis API não disponível neste navegador.');
    }
  }

  // Carrega a próxima pergunta e atualiza os prêmios
  loadQuestion(): void {
    const nextQuestion = this.questionService.nextQuestion();
    if (nextQuestion) {
      this.curQuestion = nextQuestion;  // Define a nova pergunta
      this.prizeInfo = this.questionService.getPrizeInfo();  // Atualiza os prêmios
      this.timeLeft = environment.timePerQuestion;  // Reinicia o temporizador
      this.speakText(this.curQuestion.title);  // Fala a pergunta
    } else {
      console.error('Nenhuma pergunta disponível.');
      this.finish('Fim do jogo', 'Todas as perguntas foram respondidas!', 'gameOver');
    }
  }

  // Reinicia o jogo
  restartGame(): void {
    this.clearTimer();  // Limpa qualquer temporizador anterior
    this.questionService.resetGame();  // Reseta o serviço de perguntas
    this.loadQuestion();  // Carrega a primeira pergunta
    this.startTimer();  // Inicia o temporizador
  }

  // Atualiza a interface do usuário e reinicia o temporizador
  updateUI(): void {
    this.prizeInfo = this.questionService.getPrizeInfo();  // Atualiza os prêmios
    this.timeLeft = environment.timePerQuestion;  // Reinicia o temporizador
  }

  // Finaliza o jogo exibindo um modal
  async finish(title: string, message: string, endingType: string): Promise<void> {
    this.clearTimer();  // Para o temporizador
    const modal = await this.modalCtrl.create({
      component: EndingPage,
      componentProps: { title, message, endingType },
      backdropDismiss: false,
      swipeToClose: false,
      keyboardClose: false,
    });
    await modal.present();
  }

  // Inicia o temporizador para a pergunta atual
  private startTimer(): void {
    this.clearTimer();  // Limpa o temporizador anterior, se houver
    this.intervalID = setInterval(() => {
      if (--this.timeLeft === 0) {
        this.clearTimer();
        this.finish('Fim de jogo', 'Seu tempo acabou!', 'timeout');
      }
    }, 1000);
  }

  // Limpa o temporizador
  private clearTimer(): void {
    if (this.intervalID) {
      clearInterval(this.intervalID);
      this.intervalID = null;
    }
  }

  // O jogador decide desistir
  giveUp(): void {
    this.finish('Fim de jogo', 'Você parou!', 'quit');
  }

  // O jogador responde a pergunta
  doAnswer(answer: QuestionAnswer): void {
    if (answer.isRight) {
      this.speakText('Certa resposta');
      this.loadQuestion();  // Carrega a próxima pergunta se acertar
    } else {
      this.speakText('Você errou');
      this.finish('Fim de jogo', 'Você errou!', 'wrongAnswer');  // Termina o jogo se errar
    }
  }
}